import { Postagem, Postagem_avancada } from './postagens';

class RepositorioDePostagens{
    private _postagens : Postagem[] = [];

    public inserir(postagem: Postagem){
        this._postagens.push(postagem);
    }

    public listar(): Postagem[] {
        return this._postagens;
    }
    
}

export {RepositorioDePostagens, Postagem, Postagem_avancada};