import { Postagem, Postagem_avancada, Hashtag } from "./postagens";

class Perfil {
    private static lastPerfilId: number = 0;

    private _id: number;
    private _nome: string;
    private _user: string;
    private _email: string;
    private _senha: string;
    public _postagens: Postagem[];
    public _postagensInteragidas: Postagem[] = [];
    public _postagensVistas: Postagem[] = []
    public _seguidores: Perfil[] = [];
    public _seguindo: Perfil[] = [];
    public _numeroSeguidores: number = this._seguidores.length;

    constructor(nome: string, user: string, email: string, senha: string) {
        this._id = Perfil.getNextPerfilId();
        this._nome = nome;
        this._user = user;
        this._email = email;
        this._senha = senha;
        this._postagens = [];
    }

    private static getNextPerfilId(): number {
        Perfil.lastPerfilId++;
        return Perfil.lastPerfilId;
    }

    public inserir_postagem(postagem: Postagem) {
        this._postagens.push(postagem);
    }

    public mostrarTodasAsPostagens() {
        console.log(`@${this.get_user()}, ${this.get_numeroSeguidores()} Seguidores:`);
        console.log("Postagens: \n\n")
        
        for (const postagem of this._postagens) {
            console.log('------------------------------');
            if (postagem.get_emalta()) {
                console.log("***EM ALTA***")
            }
            console.log(`${postagem.get_texto()}`);
            console.log(`Curtidas: ${postagem.get_curtidas()} | Descurtidas: ${postagem.get_descurtidas()}`);
            console.log(`${postagem.get_data()}`);
            console.log('------------------------------\n');
        }
    }

    public get_id() {
        return this._id;
    }

    public get_nome() {
        return this._nome;
    }

    public get_user() {
        return this._user;
    }

    public get_email() {
        return this._email;
    }

    public get_senha() {
        return this._senha;
    }

    public get_postagens() {
        return this._postagens;
    }

    public get_seguidores(){
        return this._seguidores;
    }

    public get_numeroSeguidores(){
        return this._numeroSeguidores;
    }   
    
    
}

export {Perfil};