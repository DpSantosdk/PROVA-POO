"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Perfil = exports.RepositorioDePerfis = void 0;
const Perfil_1 = require("./Perfil");
Object.defineProperty(exports, "Perfil", { enumerable: true, get: function () { return Perfil_1.Perfil; } });
class RepositorioDePerfis {
    constructor() {
        this._perfis = [];
    }
    incluir(perfil) {
        this._perfis.push(perfil);
    }
    consultar(user, email, senha) {
        for (const perfil of this._perfis) {
            if ((senha === undefined || perfil.get_senha() === senha) &&
                (user === undefined || perfil.get_user() === user) &&
                (email === undefined || perfil.get_email() === email)) {
                return perfil;
            }
        }
        return null;
    }
}
exports.RepositorioDePerfis = RepositorioDePerfis;
