import { RedeSocial, RepositorioDePerfis, Perfil, RepositorioDePostagens, Postagem, Postagem_avancada } from "./RedeSocial";
import { Hashtag } from "./postagens";
import { salvarDados, recuperarDados, /*salvarPostagensEmArquivo, recuperarPostagensDeArquivo*/ } from "./dados_funcao";
const readline = require('readline-sync');

class App {
    private GrakosTweet: RedeSocial;

    constructor() {
        this.GrakosTweet = new RedeSocial();
    }

    private salvarPerfis(): void {
        const perfis = this.GrakosTweet.get_perfis();
        salvarDados('perfis.txt', perfis);
    }
    
    private recuperarPerfis(): void {
        const perfisSalvos = recuperarDados('perfis.txt');
    
        if (perfisSalvos && perfisSalvos._perfis) {
            for (const perfilData of perfisSalvos._perfis) {
                const novoPerfil = new Perfil(
                    perfilData._nome,
                    perfilData._user,
                    perfilData._email,
                    perfilData._senha
                );
    
                this.GrakosTweet.incluirPerfil(novoPerfil);
            }
        }
    }   
    
    private salvarPostagens(): void {
        const postagens = this.GrakosTweet.get_postagens().listar();
        salvarDados('postagens.txt', postagens);
    }
    
    private recuperarPostagens(): void {
        const postagensSalvas = recuperarDados('postagens.txt');
    
        if (postagensSalvas) {
            for (const postagemData of postagensSalvas) {
                let novaPostagem;
    
                if (postagemData._hashtags) {
                    const hashtags = new Hashtag(postagemData._hashtags);
                    novaPostagem = new Postagem_avancada(
                        postagemData.user,
                        postagemData.texto,
                        hashtags
                    );
                } else {
                    novaPostagem = new Postagem(
                        postagemData.user,
                        postagemData.texto
                    );
                }
    
                this.GrakosTweet.incluirPostagem(novaPostagem);
            }
        }
    }


    private exibirMenuPrincipal(): string{
        console.clear();
        console.log(this.GrakosTweet.get_postagens());
        console.log("🅶 🆁 🅰 🅺 🅾 🆂 🆃 🆆 🅴 🅴 🆃");
        console.log("\n=== MENU PRINCIPAL ===");
        console.log("1. Criar Conta");
        console.log("2. Fazer Login");
        console.log("3. Sair");
        var opcao: string = readline.question("\n>> ");

        return opcao;
    }

    private criarConta(perfil: Perfil): void {
        this.GrakosTweet.incluirPerfil(perfil);
        console.log("Conta criada com sucesso!");
    }

    private fazerLogin(login: string, senha: string): Perfil | null{
        const perfilLogado = this.GrakosTweet.validar_login(login, senha);

        return perfilLogado;
    }

    private criarPostagem(perfil: Perfil): void {
        console.clear();
        console.log(`Usuário: ${perfil.get_nome()}`);
        const texto = readline.question("\nComo está se sentindo hoje?\n>> ");
        const hashtags: string[] = [];

        while (true) {
            const add: string = readline.question(`\nHashtags: ${hashtags.join(' ')}\nPara concluir a postagem ou não adicionar mais hashtags, digite (1).\n>> #`);
            if (add === '1') {
                break;
            }
            hashtags.push('#' + add);
        }

        const listaHashtags = hashtags.filter(item => item !== '#1');

        if (listaHashtags.length === 0) {
            let post = new Postagem(perfil.get_user(), texto);
            perfil.inserir_postagem(post);
            this.GrakosTweet.incluirPostagem(post);
        } else {
            let hashtagsObj = new Hashtag(listaHashtags);
            let post = new Postagem_avancada(perfil.get_user(), texto, hashtagsObj);
            perfil.inserir_postagem(post);
            this.GrakosTweet.incluirPostagem(post);
        }
        console.log("PUBLICADO!");
        readline.question("Pressione Enter para voltar ao menu.");
    }

    private verPostagens(perfil: Perfil): void {
        console.log("dataAtual\nNavegar entre postagens de todas as contas:\n");
        const todasPostagens = this.GrakosTweet.get_postagens().listar();
        if (!todasPostagens || todasPostagens.length === 0) {
            console.log("Nenhuma postagem disponível para navegar.");
            readline.question("Pressione Enter para voltar ao menu.");
            return;
        }
    
        let postagemIndex = 0;
    
        while (true) {
            const postagemAtual = todasPostagens[postagemIndex];
    
            if (!(postagemAtual instanceof Postagem_avancada) || postagemAtual.VisualizacaoRestante > 0) {
                console.clear();
                const perfildaPostagem = this.GrakosTweet.get_perfis().consultar(postagemAtual.get_user());
    
                if (perfildaPostagem) {
                    console.log(`Postagem ${postagemIndex + 1} de ${todasPostagens.length}`);
                    console.log("------------------------------");
    
                    if (postagemAtual.get_emalta()) {
                        console.log("***EM ALTA***");
                    }
    
                    console.log(`@${perfildaPostagem.get_user()} - ${perfildaPostagem.get_numeroSeguidores()} Seguidores`);
                    console.log(`\n${postagemAtual.get_texto()} - ${postagemAtual.get_data()}`);
    
                    if (postagemAtual instanceof Postagem_avancada) {
                        const hashtags = postagemAtual.get_hashtags().nome.map(hashtag => `${hashtag}`);
                        console.log(`${hashtags.join(', ')}`);
                        console.log(`\n\nVisualizações Restantes: ${postagemAtual.VisualizacaoRestante}`);
                    }
    
                    console.log("------------------------------");
                    console.log(`Curtidas: ${postagemAtual.get_curtidas()} | Descurtidas: ${postagemAtual.get_descurtidas()}`);
                    console.log("------------------------------");
                    console.log("Ações:");
                    console.log("1 - Curtir");
                    console.log("2 - Descurtir");
                    console.log("3 - Próxima Postagem");
                    console.log("4 - Voltar ao Menu");
    
                    const acao = readline.question("Digite a opção: ");
    
                    switch (acao) {
                        case "1":
                            console.clear();
                            this.GrakosTweet.curtirPostagem(perfil, postagemAtual);
                            console.log("Postagem curtida!");
                            break;
                        case "2":
                            console.clear();
                            this.GrakosTweet.descurtirPostagem(perfil, postagemAtual);
                            console.log("Postagem descurtida!");
                            break;
                        case "3":
                            console.clear();
                            if (postagemAtual instanceof Postagem_avancada) {
                                this.GrakosTweet.ViuPost(perfil, postagemAtual);
                            }
                            postagemIndex = (postagemIndex + 1) % todasPostagens.length;
                            break;
                        case "4":
                            this.salvarPerfis();
                            this.salvarPostagens();
                            if (postagemAtual instanceof Postagem_avancada) {
                                this.GrakosTweet.ViuPost(perfil, postagemAtual);
                            }
                            return;
                        default:
                            console.log("Opção inválida.");
                            break;
                    }
                } else {
                    postagemIndex = (postagemIndex + 1) % todasPostagens.length;
                }
            } else {
                postagemIndex = (postagemIndex + 1) % todasPostagens.length;
            }
        }
    }
    
    

    private BuscarPerfis(perfil: Perfil){
        const busca = readline.question("DIGITE O USUÁRIO DO PERFIL \n>> ");
        const perfilBuscado = this.GrakosTweet.get_perfis().consultar(busca);
        if (perfilBuscado) {
            console.log(`@${perfilBuscado.get_user()}, ${perfilBuscado.get_numeroSeguidores()} Seguidores:`);
            console.log("Postagens:\n");
            for (const postagem of perfilBuscado.get_postagens()) {
                console.log(postagem.get_texto());
                console.log(`Curtidas: ${postagem.get_curtidas()} | Descurtidas: ${postagem.get_descurtidas()}`);
                console.log(`${postagem.get_data()}`);
                console.log('------------------------------');
            }
            const escolha = readline.question("DESEJA SEGUIR ESTE PERFIL? (1-SIM | 2-NAO) \n>> ");
            if (escolha === "1") {
                this.GrakosTweet.adicionarSeguidor(perfilBuscado, perfil);
                console.log(`Agora você está seguindo @${perfilBuscado.get_user()}`);
            } else {
                return;
            }
        } else {
            console.log("USUÁRIO NÃO EXISTENTE");
        }

    }
    
    

    public executar(): void {
        this.recuperarPerfis();
        this.recuperarPostagens();
        let opcao: string;

        do {
        opcao = this.exibirMenuPrincipal();
        
        switch (opcao) {
            case "1":
                console.clear();
                console.log("🅶 🆁 🅰 🅺 🅾 🆂 🆃 🆆 🅴 🅴 🆃");
                var nome: string = readline.question("\nNOME: ");
                var user: string = readline.question("\nUSUÁRIO: ");
                var email: string = readline.question("\nEMAIL: ");
                var senha: string = readline.question("\nSENHA: ");

                if (nome === null || user === null || email === null || senha === null) {
                    console.log("PREENCHA TODOS OS CAMPOS CORRETAMENTE");
                } else {
                    const novoPerfil = new Perfil(nome, user, email, senha);
                    this.criarConta(novoPerfil);
                }
                break;
                case "2":
                    console.clear();
                    console.log("🅶 🆁 🅰 🅺 🅾 🆂 🆃 🆆 🅴 🅴 🆃");
                    var login: string = readline.question("\nLOGIN: ");
                    var senha: string = readline.question("\nSENHA: ");
                  
                    const perfilLogado = this.fazerLogin(login, senha);
                  
                    if (perfilLogado) {      
                        this.salvarPerfis();            
                        let opcaoInterna: string;
                        do {
                            console.clear();
                            console.log("🅶 🆁 🅰 🅺 🅾 🆂 🆃 🆆 🅴 🅴 🆃");
                            console.log(`Login bem-sucedido! Bem-vindo, @${perfilLogado.get_user()}!`);

                            console.log("\n=== MENU INTERNO ===");
                            console.log("1. CRIAR POSTAGEM");
                            console.log("2. NAVEGAR");
                            console.log("3. BUSCAR");
                            console.log("4. Voltar");
                    
                            opcaoInterna = readline.question("\n>> ");
                    
                            switch (opcaoInterna) {
                            case "1":
                                this.criarPostagem(perfilLogado);
                                break;
                            case "2":
                                this.verPostagens(perfilLogado);
                                break;
                            case "3":
                                this.BuscarPerfis(perfilLogado);
                                break;
                            case "4":
                                console.log("Voltando ao menu principal...");
                                break;
                            default:
                                console.log("Opção inválida. Tente novamente.");
                        }
                      } while (opcaoInterna !== "4");
                    } else {
                      console.log("Login falhou. Conta não encontrada.");
                    }
                    break;
                  
            case "3":
                console.log("Saindo do aplicativo. Até mais!");
                break;
            default:
                console.log("Opção inválida. Tente novamente.");
        }
        } while (opcao !== "3");
    }
}

const aplicativo = new App();
aplicativo.executar();