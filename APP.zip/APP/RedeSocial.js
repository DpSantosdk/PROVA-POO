"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Postagem_avancada = exports.Postagem = exports.RepositorioDePostagens = exports.Perfil = exports.RepositorioDePerfis = exports.RedeSocial = void 0;
const RepositorioPerfis_1 = require("./RepositorioPerfis");
Object.defineProperty(exports, "RepositorioDePerfis", { enumerable: true, get: function () { return RepositorioPerfis_1.RepositorioDePerfis; } });
Object.defineProperty(exports, "Perfil", { enumerable: true, get: function () { return RepositorioPerfis_1.Perfil; } });
const RepositorioPostagem_1 = require("./RepositorioPostagem");
Object.defineProperty(exports, "RepositorioDePostagens", { enumerable: true, get: function () { return RepositorioPostagem_1.RepositorioDePostagens; } });
Object.defineProperty(exports, "Postagem", { enumerable: true, get: function () { return RepositorioPostagem_1.Postagem; } });
Object.defineProperty(exports, "Postagem_avancada", { enumerable: true, get: function () { return RepositorioPostagem_1.Postagem_avancada; } });
class RedeSocial {
    constructor() {
        this._repositorioDePerfis = new RepositorioPerfis_1.RepositorioDePerfis();
        this._repositorioDePostagens = new RepositorioPostagem_1.RepositorioDePostagens();
    }
    validar_login(login, senha) {
        const perfilBuscado = this._repositorioDePerfis.consultar(login);
        if (perfilBuscado && perfilBuscado.get_senha() === senha) {
            return perfilBuscado;
        }
        else {
            return null;
        }
    }
    incluirPerfil(perfil) {
        const perfilExistente = this._repositorioDePerfis.consultar(perfil.get_user(), perfil.get_email(), perfil.get_senha());
        if (!perfilExistente) {
            this._repositorioDePerfis.incluir(perfil);
        }
        else {
            console.log("CONTA JÁ EXISTENTE");
        }
    }
    incluirPostagem(postagem) {
        this._repositorioDePostagens.inserir(postagem);
    }
    get_perfis() {
        return this._repositorioDePerfis;
    }
    get_postagens() {
        return this._repositorioDePostagens;
    }
    curtirPostagem(perfil, postagem) {
        if (!perfil._postagensInteragidas.includes(postagem)) {
            postagem.curtir();
            perfil._postagensInteragidas.push(postagem);
        }
        else if (perfil._postagensInteragidas.includes(postagem) && (postagem.get_foiCurtida() == false && postagem.get_foiDescurtida() == true)) {
            postagem.curtir();
        }
    }
    descurtirPostagem(perfil, postagem) {
        if (!perfil._postagensInteragidas.includes(postagem)) {
            postagem.descurtir();
            perfil._postagensInteragidas.push(postagem);
        }
        else if (perfil._postagensInteragidas.includes(postagem) && (postagem.get_foiCurtida() == true && postagem.get_foiDescurtida() == false)) {
            postagem.descurtir();
        }
    }
    ViuPost(perfil, postagem) {
        if (!perfil._postagensVistas.includes(postagem)) {
            if (postagem instanceof RepositorioPostagem_1.Postagem_avancada) {
                postagem.FoiVisto = false;
                postagem.DecrementarVisualizacao();
            }
            perfil._postagensVistas = perfil._postagensVistas.filter(p => p !== postagem);
        }
        else {
            console.log("Você viu esta postagem.");
        }
    }
    adicionarSeguidor(perfil, seguidor) {
        if (!perfil._seguidores.includes(seguidor)) {
            perfil._seguidores.push(seguidor);
            seguidor._seguindo.push(perfil);
            perfil._numeroSeguidores = perfil._seguidores.length;
        }
    }
}
exports.RedeSocial = RedeSocial;
