"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Postagem_avancada = exports.Postagem = exports.RepositorioDePostagens = void 0;
const postagens_1 = require("./postagens");
Object.defineProperty(exports, "Postagem", { enumerable: true, get: function () { return postagens_1.Postagem; } });
Object.defineProperty(exports, "Postagem_avancada", { enumerable: true, get: function () { return postagens_1.Postagem_avancada; } });
class RepositorioDePostagens {
    constructor() {
        this._postagens = [];
    }
    inserir(postagem) {
        this._postagens.push(postagem);
    }
    listar() {
        return this._postagens;
    }
}
exports.RepositorioDePostagens = RepositorioDePostagens;
