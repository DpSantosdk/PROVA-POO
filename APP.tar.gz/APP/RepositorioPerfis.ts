import { Perfil } from './Perfil';

class RepositorioDePerfis {
  private _perfis: Perfil[] = [];

  incluir(perfil: Perfil): void {
    this._perfis.push(perfil);
  }

  consultar(user?: string, email?: string, senha?: string): Perfil | null {
    for (const perfil of this._perfis) {
      if (
        (senha === undefined || perfil.get_senha() === senha) &&
        (user === undefined || perfil.get_user() === user) &&
        (email === undefined || perfil.get_email() === email)
      ) {
        return perfil;
      }
    }

    return null;
  }
}

export { RepositorioDePerfis, Perfil };
