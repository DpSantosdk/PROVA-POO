"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Perfil = void 0;
class Perfil {
    constructor(nome, user, email, senha) {
        this._postagensInteragidas = [];
        this._postagensVistas = [];
        this._seguidores = [];
        this._seguindo = [];
        this._numeroSeguidores = this._seguidores.length;
        this._id = Perfil.getNextPerfilId();
        this._nome = nome;
        this._user = user;
        this._email = email;
        this._senha = senha;
        this._postagens = [];
    }
    static getNextPerfilId() {
        Perfil.lastPerfilId++;
        return Perfil.lastPerfilId;
    }
    inserir_postagem(postagem) {
        this._postagens.push(postagem);
    }
    mostrarTodasAsPostagens() {
        console.log(`@${this.get_user()}, ${this.get_numeroSeguidores()} Seguidores:`);
        console.log("Postagens: \n\n");
        for (const postagem of this._postagens) {
            console.log('------------------------------');
            if (postagem.get_emalta()) {
                console.log("***EM ALTA***");
            }
            console.log(`${postagem.get_texto()}`);
            console.log(`Curtidas: ${postagem.get_curtidas()} | Descurtidas: ${postagem.get_descurtidas()}`);
            console.log(`${postagem.get_data()}`);
            console.log('------------------------------\n');
        }
    }
    get_id() {
        return this._id;
    }
    get_nome() {
        return this._nome;
    }
    get_user() {
        return this._user;
    }
    get_email() {
        return this._email;
    }
    get_senha() {
        return this._senha;
    }
    get_postagens() {
        return this._postagens;
    }
    get_seguidores() {
        return this._seguidores;
    }
    get_numeroSeguidores() {
        return this._numeroSeguidores;
    }
}
exports.Perfil = Perfil;
Perfil.lastPerfilId = 0;
