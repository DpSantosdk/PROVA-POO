"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Hashtag = exports.Postagem_avancada = exports.Postagem = void 0;
class Hashtag {
    constructor(nome) {
        this.nome = nome;
    }
}
exports.Hashtag = Hashtag;
class Postagem {
    constructor(perfil, texto) {
        this.foiCurtida = false;
        this.foiDescurtida = false;
        this.EmAlta = false;
        this.id = 0;
        this.perfil = perfil;
        this.texto = texto;
        this.curtidas = 0;
        this.descurtidas = 0;
        this.foiCurtida = false;
        this.foiDescurtida = false;
        this.data = new Date().toLocaleDateString();
    }
    get_perfil() {
        return this.perfil;
    }
    get_texto() {
        return this.texto;
    }
    get_curtidas() {
        return this.curtidas;
    }
    get_descurtidas() {
        return this.descurtidas;
    }
    get_foiCurtida() {
        return this.foiCurtida;
    }
    get_foiDescurtida() {
        return this.foiDescurtida;
    }
    get_data() {
        return this.data;
    }
    get_emalta() {
        return this.EmAlta;
    }
    EhPopular() {
        if (this.curtidas - this.descurtidas > (this.curtidas / 2)) {
            this.EmAlta = true;
        }
    }
    curtir() {
        this.curtidas++;
        if (this.descurtidas > 0) {
            this.descurtidas--;
        }
        this.foiCurtida = true;
        this.foiDescurtida = false;
        this.EhPopular();
    }
    descurtir() {
        this.descurtidas++;
        if (this.curtidas > 0) {
            this.curtidas--;
        }
        this.foiCurtida = false;
        this.foiDescurtida = true;
    }
}
exports.Postagem = Postagem;
class Postagem_avancada extends Postagem {
    constructor(perfil, texto, hashtags) {
        super(perfil, texto);
        this.FoiVisto = false;
        this.hashtags = hashtags;
        this.VisualizacaoRestante = 5;
        this.FoiVisto = false;
    }
    get_hashtags() {
        return this.hashtags;
    }
    DecrementarVisualizacao() {
        if (!this.FoiVisto) {
            this.VisualizacaoRestante--;
            this.FoiVisto = true;
        }
        else {
            console.log("Já foi visto por você.");
        }
    }
}
exports.Postagem_avancada = Postagem_avancada;
