import { RepositorioDePerfis, Perfil } from './RepositorioPerfis';
import { RepositorioDePostagens, Postagem, Postagem_avancada } from './RepositorioPostagem';

class RedeSocial {
    private _repositorioDePerfis: RepositorioDePerfis;
    private _repositorioDePostagens: RepositorioDePostagens;
  
    constructor() {
      this._repositorioDePerfis = new RepositorioDePerfis();
      this._repositorioDePostagens = new RepositorioDePostagens();
    }
  
    public validar_login(login: string, senha: string): Perfil | null {
      const perfilBuscado = this._repositorioDePerfis.consultar(login);
      
      if (perfilBuscado && perfilBuscado.get_senha() === senha) {
        return perfilBuscado;
      } else {
        return null;
      }
    }
  
    public incluirPerfil(perfil: Perfil): void {
        const perfilExistente = this._repositorioDePerfis.consultar(perfil.get_user(), perfil.get_email(), perfil.get_senha());
    
        if (!perfilExistente) {
          this._repositorioDePerfis.incluir(perfil);
        } else {
          console.log("CONTA JÁ EXISTENTE");
        }
    }

    public incluirPostagem(postagem: Postagem): void{
      this._repositorioDePostagens.inserir(postagem);
    }

    public get_perfis(){
        return this._repositorioDePerfis;
    }

    public get_postagens(){
      return this._repositorioDePostagens;
    }

    public curtirPostagem(perfil:Perfil, postagem: Postagem) {
      if (!perfil._postagensInteragidas.includes(postagem)) {
          postagem.curtir();
          perfil._postagensInteragidas.push(postagem);
      } else if (perfil._postagensInteragidas.includes(postagem) && (postagem.get_foiCurtida() == false && postagem.get_foiDescurtida() == true)) {
        postagem.curtir();
      }
    }
    
    public descurtirPostagem(perfil:Perfil, postagem: Postagem) {
        if (!perfil._postagensInteragidas.includes(postagem)) {
            postagem.descurtir();
            perfil._postagensInteragidas.push(postagem);
        } else if (perfil._postagensInteragidas.includes(postagem) && (postagem.get_foiCurtida() == true && postagem.get_foiDescurtida() == false)) {
          postagem.descurtir();
        }
    }
    
    

    public ViuPost(perfil:Perfil, postagem: Postagem){
        if (!perfil._postagensVistas.includes(postagem)) {
            if (postagem instanceof Postagem_avancada) {
                postagem.FoiVisto = false;
                postagem.DecrementarVisualizacao();
            }
            perfil._postagensVistas = perfil._postagensVistas.filter(p => p !== postagem);
        } else {
            console.log("Você viu esta postagem.");
        }
    }

    public adicionarSeguidor(perfil:Perfil, seguidor: Perfil) {
      if (!perfil._seguidores.includes(seguidor)) {
        perfil._seguidores.push(seguidor);
        seguidor._seguindo.push(perfil);
        perfil._numeroSeguidores = perfil._seguidores.length;
      }
    }
    
} 

export { RedeSocial, RepositorioDePerfis, Perfil, RepositorioDePostagens, Postagem, Postagem_avancada };
