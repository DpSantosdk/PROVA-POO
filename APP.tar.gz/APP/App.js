"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const RedeSocial_1 = require("./RedeSocial");
const postagens_1 = require("./postagens");
const dados_funcao_1 = require("./dados_funcao");
const readline = require('readline-sync');
class App {
    constructor() {
        this.GrakosTweet = new RedeSocial_1.RedeSocial();
    }
    salvarPerfis() {
        const perfis = this.GrakosTweet.get_perfis();
        (0, dados_funcao_1.salvarDados)('perfis.txt', perfis);
    }
    recuperarPerfis() {
        const perfisSalvos = (0, dados_funcao_1.recuperarDados)('perfis.txt');
        if (perfisSalvos && perfisSalvos._perfis) {
            for (const perfilData of perfisSalvos._perfis) {
                const novoPerfil = new RedeSocial_1.Perfil(perfilData._nome, perfilData._user, perfilData._email, perfilData._senha);
                // Adicione outras propriedades conforme necessário
                // Adicione o perfil criado
                this.GrakosTweet.incluirPerfil(novoPerfil);
            }
        }
    }
    salvarPostagens() {
        const postagens = this.GrakosTweet.get_postagens();
        (0, dados_funcao_1.salvarDados)('postagens.txt', postagens);
    }
    recuperarPostagens() {
        const postagensSalvas = (0, dados_funcao_1.recuperarDados)('postagens.txt');
        if (postagensSalvas && postagensSalvas._postagens) {
            for (const postagemData of postagensSalvas._postagens) {
                let novaPostagem;
                if (postagemData._hashtags) {
                    const hashtags = new postagens_1.Hashtag(postagemData._hashtags);
                    novaPostagem = new RedeSocial_1.Postagem_avancada(postagemData._perfil, postagemData._texto, hashtags);
                }
                else {
                    novaPostagem = new RedeSocial_1.Postagem(postagemData._perfil, postagemData._texto);
                }
                // Adicione outras propriedades conforme necessário
                // Adicione a postagem criada
                this.GrakosTweet.incluirPostagem(novaPostagem);
            }
        }
    }
    exibirMenuPrincipal() {
        console.clear();
        console.log("🅶 🆁 🅰 🅺 🅾 🆂 🆃 🆆 🅴 🅴 🆃");
        console.log("\n=== MENU PRINCIPAL ===");
        console.log("1. Criar Conta");
        console.log("2. Fazer Login");
        console.log("3. Sair");
        var opcao = readline.question("\n>> ");
        return opcao;
    }
    criarConta(perfil) {
        this.GrakosTweet.incluirPerfil(perfil);
        console.log("Conta criada com sucesso!");
    }
    fazerLogin(login, senha) {
        const perfilLogado = this.GrakosTweet.validar_login(login, senha);
        return perfilLogado;
    }
    criarPostagem(perfil) {
        console.clear();
        console.log(`Usuário: ${perfil.get_nome()}`);
        const texto = readline.question("\nComo está se sentindo hoje?\n>> ");
        const hashtags = [];
        while (true) {
            const add = readline.question(`\nHashtags: ${hashtags.join(' ')}\nPara concluir a postagem ou não adicionar mais hashtags, digite (1).\n>> #`);
            if (add === '1') {
                break;
            }
            hashtags.push('#' + add);
        }
        const listaHashtags = hashtags.filter(item => item !== '#1');
        if (listaHashtags.length === 0) {
            let post = new RedeSocial_1.Postagem(perfil, texto);
            perfil.inserir_postagem(post);
            this.GrakosTweet.incluirPostagem(post);
        }
        else {
            let hashtagsObj = new postagens_1.Hashtag(listaHashtags);
            let post = new RedeSocial_1.Postagem_avancada(perfil, texto, hashtagsObj);
            perfil.inserir_postagem(post);
            this.GrakosTweet.incluirPostagem(post);
        }
        this.salvarPostagens();
        console.log("PUBLICADO!");
        readline.question("Pressione Enter para voltar ao menu.");
    }
    verPostagens(perfil) {
        console.log("dataAtual" + "\nNavegar entre postagens de todas as contas:\n");
        const todasPostagens = this.GrakosTweet.get_postagens().listar(); // Assumindo que existe um método listar() que retorna um array de postagens
        if (!todasPostagens || todasPostagens.length === 0) {
            console.log("Nenhuma postagem disponível para navegar.");
            readline.question("Pressione Enter para voltar ao menu.");
            return;
        }
        let postagemIndex = 0;
        while (true) {
            const postagemAtual = todasPostagens[postagemIndex];
            if (!(postagemAtual instanceof RedeSocial_1.Postagem_avancada) || postagemAtual.VisualizacaoRestante > 0) {
                console.clear();
                const perfildaPostagem = postagemAtual.get_perfil();
                console.log(`Postagem ${postagemIndex + 1} de ${todasPostagens.length}`);
                console.log("------------------------------");
                if (postagemAtual.get_emalta()) {
                    console.log("***EM ALTA***");
                }
                console.log(`@${perfildaPostagem.get_user()} - ${perfildaPostagem.get_numeroSeguidores()} Seguidores`);
                console.log(`\n${postagemAtual.get_texto()} - ${postagemAtual.get_data()}`);
                if (postagemAtual instanceof RedeSocial_1.Postagem_avancada) {
                    const hashtags = postagemAtual.get_hashtags().nome.map(hashtag => `${hashtag}`);
                    console.log(`${hashtags.join(', ')}`);
                    console.log(`\n\nVisualizações Restantes: ${postagemAtual.VisualizacaoRestante}`);
                }
                console.log("------------------------------");
                console.log(`Curtidas: ${postagemAtual.get_curtidas()} | Descurtidas: ${postagemAtual.get_descurtidas()}`);
                console.log("------------------------------");
                console.log("Ações:");
                console.log("1 - Curtir");
                console.log("2 - Descurtir");
                console.log("3 - Próxima Postagem");
                console.log("4 - Voltar ao Menu");
                const acao = readline.question("Digite a opção: ");
                switch (acao) {
                    case "1":
                        console.clear();
                        this.GrakosTweet.curtirPostagem(perfil, postagemAtual);
                        console.log("Postagem curtida!");
                        break;
                    case "2":
                        console.clear();
                        this.GrakosTweet.descurtirPostagem(perfil, postagemAtual);
                        console.log("Postagem descurtida!");
                        break;
                    case "3":
                        console.clear();
                        if (postagemAtual instanceof RedeSocial_1.Postagem_avancada) {
                            this.GrakosTweet.ViuPost(perfil, postagemAtual);
                        }
                        postagemIndex = (postagemIndex + 1) % todasPostagens.length;
                        break;
                    case "4":
                        if (postagemAtual instanceof RedeSocial_1.Postagem_avancada) {
                            this.GrakosTweet.ViuPost(perfil, postagemAtual);
                        }
                        return;
                    default:
                        console.log("Opção inválida.");
                        break;
                }
            }
            else {
                postagemIndex = (postagemIndex + 1) % todasPostagens.length;
            }
        }
    }
    BuscarPerfis(perfil) {
        const busca = readline.question("DIGITE O USUÁRIO DO PERFIL \n>> ");
        const perfilBuscado = this.GrakosTweet.get_perfis().consultar(busca);
        if (perfilBuscado) {
            console.log(`@${perfilBuscado.get_user()}, ${perfilBuscado.get_numeroSeguidores()} Seguidores:`);
            console.log("Postagens:\n");
            for (const postagem of perfilBuscado.get_postagens()) {
                console.log(postagem.get_texto());
                console.log(`Curtidas: ${postagem.get_curtidas()} | Descurtidas: ${postagem.get_descurtidas()}`);
                console.log(`${postagem.get_data()}`);
                console.log('------------------------------');
            }
            const escolha = readline.question("DESEJA SEGUIR ESTE PERFIL? (1-SIM | 2-NAO) \n>> ");
            if (escolha === "1") {
                this.GrakosTweet.adicionarSeguidor(perfilBuscado, perfil);
                console.log(`Agora você está seguindo @${perfilBuscado.get_user()}`);
            }
            else {
                return;
            }
        }
        else {
            console.log("USUÁRIO NÃO EXISTENTE");
        }
    }
    executar() {
        this.recuperarPerfis();
        this.recuperarPostagens();
        let opcao;
        do {
            opcao = this.exibirMenuPrincipal();
            switch (opcao) {
                case "1":
                    console.clear();
                    console.log("🅶 🆁 🅰 🅺 🅾 🆂 🆃 🆆 🅴 🅴 🆃");
                    var nome = readline.question("\nNOME: ");
                    var user = readline.question("\nUSUÁRIO: ");
                    var email = readline.question("\nEMAIL: ");
                    var senha = readline.question("\nSENHA: ");
                    if (nome === null || user === null || email === null || senha === null) {
                        console.log("PREENCHA TODOS OS CAMPOS CORRETAMENTE");
                    }
                    else {
                        const novoPerfil = new RedeSocial_1.Perfil(nome, user, email, senha);
                        this.criarConta(novoPerfil);
                        this.salvarPerfis();
                    }
                    break;
                case "2":
                    console.clear();
                    console.log("🅶 🆁 🅰 🅺 🅾 🆂 🆃 🆆 🅴 🅴 🆃");
                    var login = readline.question("\nLOGIN: ");
                    var senha = readline.question("\nSENHA: ");
                    const perfilLogado = this.fazerLogin(login, senha);
                    if (perfilLogado) {
                        this.salvarPerfis();
                        let opcaoInterna;
                        do {
                            console.clear();
                            console.log("🅶 🆁 🅰 🅺 🅾 🆂 🆃 🆆 🅴 🅴 🆃");
                            console.log(`Login bem-sucedido! Bem-vindo, @${perfilLogado.get_user()}!`);
                            console.log("\n=== MENU INTERNO ===");
                            console.log("1. CRIAR POSTAGEM");
                            console.log("2. NAVEGAR");
                            console.log("3. BUSCAR");
                            console.log("4. Voltar");
                            opcaoInterna = readline.question("\n>> ");
                            switch (opcaoInterna) {
                                case "1":
                                    this.criarPostagem(perfilLogado);
                                    break;
                                case "2":
                                    this.verPostagens(perfilLogado);
                                    break;
                                case "3":
                                    this.BuscarPerfis(perfilLogado);
                                    break;
                                case "4":
                                    console.log("Voltando ao menu principal...");
                                    break;
                                default:
                                    console.log("Opção inválida. Tente novamente.");
                            }
                        } while (opcaoInterna !== "4");
                    }
                    else {
                        console.log("Login falhou. Conta não encontrada.");
                    }
                    break;
                case "3":
                    console.log("Saindo do aplicativo. Até mais!");
                    break;
                default:
                    console.log("Opção inválida. Tente novamente.");
            }
        } while (opcao !== "3");
    }
}
// Uso da classe App
const aplicativo = new App();
aplicativo.executar();
