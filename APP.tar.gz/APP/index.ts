/*

const readline = require('readline-sync');
import { Perfil } from './Perfil';
import { postagem, postagem_avancada, Hashtag } from './postagens';
import { RedeSocial } from './RedeSocial';

// Funções relacionadas a leitura do usuário
function obterOpcao() {
    console.log("\n 1 - CRIAR POSTAGEM \n 2 - BUSCAR \n 3 - NAVEGAR ENTRE POSTAGENS \n 4 - LOGOUT");
    return readline.question("Digite a opção: ");
}

function criarPostagem(perfil: Perfil, redeSocial: RedeSocial) {
    console.clear();
    console.log(`Usuário: ${perfil.get_nome()}`);
    const texto = readline.question("\n Como está se sentindo hoje? \n>> ");
    const hashtags = [];
    while (true) {
        const add: string = readline.question(`\n Hashtags: ${hashtags.join(' ')}\n Para concluir a postagem ou não adicionar mais hashtags, digite (1).\n>> #`);
        if (add === '1') {
            break;
        }
        hashtags.push('#' + add);
    }
    const listaHashtags = hashtags.filter(item => item !== '#1');
    if (listaHashtags.length === 0) {
        let post = new postagem(perfil, texto);
        perfil.inserir_postagem(post);
        redeSocial.inserir_post(post);
    } else {
        let hashtagsObj = new Hashtag(listaHashtags);
        let post = new postagem_avancada(perfil, texto, hashtagsObj);
        perfil.inserir_postagem(post);
        redeSocial.inserir_post(post);
    }
    console.log("Postagem criada com sucesso!");
    readline.question("Pressione Enter para voltar ao menu.");
}

function buscarOpcoes(perfil: Perfil, redeSocial: RedeSocial) {
    while (true) {
        console.clear();
        console.log("1- BUSCAR USUÁRIO");
        console.log("2- BUSCAR POSTAGEM");
        console.log("3- SAIR");
        const opcao = readline.question("Digite a opção: ");
        switch (opcao) {
            case "1":
                const busca = readline.question("DIGITE O USUÁRIO DO PERFIL \n>> ");
                const perfilBuscado = redeSocial.buscar_perfil(busca);
                if (perfilBuscado) {
                    console.log(`@${perfilBuscado.get_user()}, ${perfilBuscado.get_numeroSeguidores()} Seguidores:`);
                    console.log("Postagens:\n");
                    for (const postagem of perfilBuscado.get_postagens()) {
                        console.log(postagem.get_texto());
                        console.log(`Curtidas: ${postagem.get_curtidas()} | Descurtidas: ${postagem.get_descurtidas()}`);
                        console.log(`${postagem.get_data()}`);
                        console.log('------------------------------');
                    }
                    const escolha = readline.question("DESEJA SEGUIR ESTE PERFIL? (1-SIM | 2-NAO) \n>> ");
                    if (escolha === "1") {
                        perfil.seguir_perfil(perfilBuscado);
                        console.log(`Agora você está seguindo @${perfilBuscado.get_user()}`);
                    } else {
                        break;
                    }
                } else {
                    console.log("USUÁRIO NÃO EXISTENTE");
                }
                break;
            case "2":
                const opcaoBusca = readline.question("1- BUSCAR POR TEXTO\n2- BUSCAR POR HASHTAG\n>> ");
                if (opcaoBusca === "1") {
                    const busca = readline.question("DIGITE O TEXTO: ");
                    const postagensEncontradas = redeSocial.buscarPostagens(busca);
                    if (postagensEncontradas.length > 0) {
                        console.log("Postagens encontradas:\n");
                        for (const postagem of postagensEncontradas) {
                            console.log(postagem);
                            console.log('------------------------------');
                        }
                    } else {
                        console.log("Nenhuma postagem encontrada com esse texto.");
                    }
                } else if (opcaoBusca === "2") {
                    const busca = readline.question("DIGITE A HASHTAG: ");
                    const postagensEncontradas = redeSocial.filtrarPostagensPorHashtag(busca);
                    if (postagensEncontradas.length > 0) {
                        console.log("Postagens encontradas:\n");
                        for (const postagem of postagensEncontradas) {
                            console.log(`Texto: ${postagem.get_texto()}`);
                            console.log(`Curtidas: ${postagem.get_curtidas()} | Descurtidas: ${postagem.get_descurtidas()}`);
                            console.log(`Data: ${postagem.get_data()}`);
                            //console.log(`Hashtags: #${postagem.get_hashtags().nome.join(' #')}`);
                            console.log('------------------------------');
                        }
                    } else {
                        console.log("Nenhuma postagem encontrada com essa hashtag.");
                    }
                }
                break;
            case "3":
                return;
            default:
                console.log("Opção inválida.");
                break;
        }
    }
}

function navegarPostagens(perfil: Perfil, redeSocial: RedeSocial) {
    console.clear();
    console.log("dataAtual" + "\nNavegar entre postagens de todas as contas:\n");
    const todasPostagens = redeSocial.post;
    if (todasPostagens.length === 0) {
        console.log("Nenhuma postagem disponível para navegar.");
        readline.question("Pressione Enter para voltar ao menu.");
        return;
    }
    let postagemIndex = 0;
    while (true) {
        const postagemAtual = todasPostagens[postagemIndex];
        if (!(postagemAtual instanceof postagem_avancada) || postagemAtual.VisualizacaoRestante > 0) {
            console.clear();
            const perfildaPostagem = postagemAtual.get_perfil();
            console.log(`Postagem ${postagemIndex + 1} de ${todasPostagens.length}`);
            console.log("------------------------------");
            if (postagemAtual.get_emalta()) {
                console.log("***EM ALTA***")
            }
            console.log(`@${perfildaPostagem.get_user()} - ${perfildaPostagem.get_numeroSeguidores()} Seguidores`);
            console.log(`${postagemAtual.get_texto()} - ${postagemAtual.get_data()}`);
            if (postagemAtual instanceof postagem_avancada) {
                const hashtags = postagemAtual.get_hashtags().nome.map(hashtag => `#${hashtag}`);
                console.log(`${hashtags.join(', ')}`);
                console.log(`Visualizações Restantes: ${postagemAtual.VisualizacaoRestante}`);
            }
            console.log("------------------------------");
            console.log(`Curtidas: ${postagemAtual.get_curtidas()} | Descurtidas: ${postagemAtual.get_descurtidas()}`);
            console.log("------------------------------");
            console.log("Ações:");
            console.log("1 - Curtir");
            console.log("2 - Descurtir");
            console.log("3 - Próxima Postagem");
            console.log("4 - Voltar ao Menu");
            const acao = readline.question("Digite a opção: ");
            switch (acao) {
                case "1":
                    console.clear();
                    perfil.curtirPostagem(postagemAtual);
                    console.log("Postagem curtida!");
                    break;
                case "2":
                    console.clear();
                    perfil.descurtirPostagem(postagemAtual);
                    console.log("Postagem descurtida!");
                    break;
                case "3":
                    console.clear();
                    if (postagemAtual instanceof postagem_avancada) {
                        perfil.ViuPost(postagemAtual);
                    }
                    postagemIndex = (postagemIndex + 1) % todasPostagens.length;
                    break;
                case "4":
                    if (postagemAtual instanceof postagem_avancada) {
                        perfil.ViuPost(postagemAtual);
                    }
                    return;
                default:
                    console.log("Opção inválida.");
                    break;
            }
        } else {
            postagemIndex = (postagemIndex + 1) % todasPostagens.length;
        }
    }
}

*/