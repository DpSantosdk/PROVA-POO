import * as fs from 'fs';
import * as CircularJSON from 'circular-json';
import { Postagem, Postagem_avancada } from "./postagens";

function salvarDados(nomeArquivo: string, objeto: any): void {
  const dados = CircularJSON.stringify(objeto);
  fs.writeFileSync(nomeArquivo, dados);
}

function recuperarDados(nomeArquivo: string): any | null {
  try {
    const dados = fs.readFileSync(nomeArquivo, 'utf-8');
    return CircularJSON.parse(dados);
  } catch (error) {
    return null;
  }
}


function salvarPostagensEmArquivo(nomeArquivo: string, postagens: Postagem[]): void {
    // Converte as postagens para formato JSON
    const postagensJSON = CircularJSON.stringify(postagens);

    // Escreve no arquivo
    fs.writeFileSync(nomeArquivo, postagensJSON);
}

function recuperarPostagensDeArquivo(nomeArquivo: string): Postagem[] {
    try {
        const postagensJSON = fs.readFileSync(nomeArquivo, 'utf-8');
        return CircularJSON.parse(postagensJSON);
    } catch (error) {
        console.error('Erro ao recuperar postagens do arquivo:', error);
        return [];
    }
}


export {salvarDados, recuperarDados, salvarPostagensEmArquivo, recuperarPostagensDeArquivo };